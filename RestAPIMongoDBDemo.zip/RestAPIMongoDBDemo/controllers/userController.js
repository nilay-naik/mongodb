const userModel = require('../models/userModel');
const {v4: uuidv4} = require('uuid');

function GetUsers(req,res)
{
    userModel.find({},(err,data)=>{
        if(!err)
        {
            res.status(200).send(data);
        }
    })
}


function AddUser(req,res)
{
    let user = new userModel({
        _id: uuidv4(),
        fName: req.body.fName,
        lName:req.body.lName,
        email:req.body.email,
        city:req.body.city,
        age:req.body.age
    });

    user.save((err)=>{
        if(!err)
        {
            res.status(201).send({message: "User Added Successfully ..."});
        }
        else
        {
            throw err
        }
    });
}

module.exports = {GetUsers,AddUser}