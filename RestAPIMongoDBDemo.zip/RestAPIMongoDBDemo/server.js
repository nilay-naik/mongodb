const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes');
const app = express();

app.use(bodyParser.json());
app.use('/api/v1',userRoutes);

mongoose.connect('mongodb://localhost:27017/test');
mongoose.connection.once('open',()=>{

    console.log("Connected with MongoDB ....");

}).on('error',(err)=>{
    console.log(err);
})

app.listen(8000,()=>{
    console.log('Server Started On Port 8000 ...');
});