const express = require('express');
const { GetUsers,AddUser } = require('../controllers/userController');

const router = express.Router();

router.get('/users',GetUsers);
router.post('/adduser',AddUser);

module.exports = router;